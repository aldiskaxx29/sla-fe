const ExecutivePage = () => {
  return (
    <iframe
      src="http://10.60.174.187:90/devel/?page=executive"
      title="Executive Dashboard"
      className="w-full min-h-[100vh]"
    />
  );
};

export default ExecutivePage;
