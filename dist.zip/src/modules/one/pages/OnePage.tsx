const OnePage = () => {
  return (
    <iframe
      src="http://10.62.175.157/one/main-v2"
      title="One Visibility Dashboard"
      className="w-full min-h-[100vh]"
    />
  );
};

export default OnePage;
