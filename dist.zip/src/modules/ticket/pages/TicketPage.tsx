const TicketPage = () => {
    return (
      <iframe
        src="http://10.60.174.187:90/ticket_quality_v3/"
        title="Ticket Quality"
        className="w-full min-h-[100vh]"
      />
    );
  };
  
  export default TicketPage;
  