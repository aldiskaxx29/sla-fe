const ELibraryPage = () => {
  return (
    <iframe
      src="http://10.62.175.156/doc/umum"
      title="E Library"
      className="w-full min-h-[100vh]"
    />
  );
};

export default ELibraryPage;
