// Interfaces
import { IAuthAuthenticatedUser } from "./auth.interface";

export interface IAuthSliceInitialState {
  auth_authenticatedUser: IAuthAuthenticatedUser;
}
