const MondayPage = () => {
  return (
    <iframe
      src="http://10.60.174.187:90/mondaymonitoring/"
      title="Monday Monitoring Dashboard"
      className="w-full min-h-[100vh]"
    />
  );
};

export default MondayPage;
